<?php
// get the data via POST 
// read the input file into a string
// json_decode converts a JSON object into a PHP array (if second arg. is true)
$post_data = json_decode(file_get_contents('php://input'), true);
$data = $post_data['filedata'];

// generate a unique ID for the file with prefix 'session-'
$file = uniqid("exp_2-");

// note: the directory "data" must be writable by the server
$name = "../data/{$file}.csv";

// write the file to disk
file_put_contents($name, $data);
?>




