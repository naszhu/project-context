function create_stimulus_table(attribute_name_1='Attribute 1',attribute_name_2='Attribute 2',
			alternative_name_1='Alternative 1',alternative_name_2='Alternative 2',alternative_name_3='Alternative 3')
		{
			/*
			function to create the stimulus table
			attribute_name_1 (2) is the name of the first attribute
			alternative_name_1 (2 and 3) are the names of the three alternatives
			*/

			var table_html = `
		                    
							<div id='Table1' class='AttributeTable'>
		                    <table>
								  <tr>
								    <td></td>

								    <td><b>`+attribute_name_1+`</b></td>
								    <td><b>`+attribute_name_2+`</b></td>
								  </tr>
								  <tr>
									  <td height = "10vh">
									  </td> 
								  </tr>
								  <tr>
									    <td id="name_1" width="400"> <b>`+alternative_name_1+`</b></td>
									    <td id="att11" width="400" height="10vh">
									    </td>
									    <td id="att12" width="400" height="10vh">
									    </td>
								  </tr>
								  <tr>
									  <td height = "10vh">
									  </td> 
								  </tr>
								  <tr>
									    <td id="name_2" width="400"> <b>`+alternative_name_2+`</b></td>
									    <td id="att21" width="400" height="10vh"></td>
									    <td id="att22"width="400" height="10vh"> </td>

								  </tr>
								  <tr>
									  <td height = "10vh">
									  </td> 
								  </tr>
								  <tr>
									    <td id="name_3" width="400"><b>`+alternative_name_3+`</b></td>
									    <td id="att31" width="400" height="10vh"> </td>
									    <td id="att32" width="400" height="10vh"> </td>
								  </tr>
								  <tr>
									  <td height = "10vh">
									  </td> 
								  </tr>

								</table>
							</div>
							</div>
								`

												
                return table_html;
            }
 //           function fill_table_wrapper(attribute_11,attribute_12,attribute_21,attribute_22,attribute_31,attribute_32) {
            		function fill_table(attribute_11,attribute_12,attribute_21,attribute_22,attribute_31,attribute_32,color_1,color_2,color_3,
            			background_color_1,background_color_2,background_color_3,background_color) {

			           	background_color_string="background-color:"+background_color+';';
			           	document.getElementById('entirebody').setAttribute('style',background_color_string);
						
			           	//var alternative_1 = document.getElementById('alternative_1');
						//alternative_1.setAttribute('style','background-color: #f1f1f1;');
						//console.log(alternative_1);


			           	var cell_11 = document.getElementById('att11');
			           	cell_11.setAttribute('style',"color: "+color_1+"; background-color: "+background_color_1+" ;");	           	
			           	cell_11.innerHTML = attribute_11;

						var cell_12 = document.getElementById('att12');
			           	cell_12.setAttribute('style',"color:"+color_1+";"+"background-color: "+background_color_1+";");
			           	cell_12.innerHTML = attribute_12;
						
			           	var cell_21 = document.getElementById('att21');			           	
			           	cell_21.setAttribute('style',"color:"+color_2+";"+" background-color: "+background_color_2+";");
			           	cell_21.innerHTML = attribute_21;

			           	var cell_22 = document.getElementById('att22');
			           	cell_22.setAttribute('style',"color:"+color_2+";"+" background-color: "+background_color_2+";");
			           	cell_22.innerHTML = attribute_22;

			           	var cell_31 = document.getElementById('att31')
			           	cell_31.setAttribute('style',"color:"+color_3+";"+" background-color: "+background_color_3+";");
			           	cell_31.innerHTML = attribute_31;

			           	var cell_32 = document.getElementById('att32')
			           	cell_32.setAttribute('style',"color:"+color_3+";"+" background-color: "+background_color_3+";");

			           	cell_32.innerHTML = attribute_32;
						//const myChart11 = attribute_11;
						
						var name_1 = document.getElementById('name_1');
			           	name_1.setAttribute('style',"color: "+color_1+"; background-color: "+background_color_1+" ;");	           	
						var name_2 = document.getElementById('name_2');
			           	name_2.setAttribute('style',"color: "+color_2+"; background-color: "+background_color_2+" ;");	           	
						var name_3 = document.getElementById('name_3');
			           	name_3.setAttribute('style',"color: "+color_3+"; background-color: "+background_color_3+" ;");	           	
			           	

			    		console.log('The trial just finished loading.');
		  			}
	//	  		}return fill_table


